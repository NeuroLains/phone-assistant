package ru.neurolains.phoneassistant;

import android.accessibilityservice.AccessibilityService;
import android.app.KeyguardManager;
import android.content.*;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.view.accessibility.*;
import org.json.*;
import java.util.*;

public class PhoneAccess extends AccessibilityService {
    static PhoneAccess instance;
    @Override protected void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}
    @Override public void onInterrupt() {}
    @Override public void onDestroy() { instance = null; super.onDestroy(); }
    boolean locked() { return getSystemService(KeyguardManager.class).isKeyguardLocked(); }
    AccessibilityNodeInfo appRoot() {
        if (locked()) return null;
        for (AccessibilityWindowInfo w : getWindows()) {
            if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            AccessibilityNodeInfo root = w.getRoot();
            if (root != null && !getPackageName().contentEquals(root.getPackageName() == null ? "" : root.getPackageName())) return root;
        }
        return null;
    }
    static List<AccessibilityNodeInfo> nodes(AccessibilityNodeInfo root) {
        ArrayList<AccessibilityNodeInfo> out = new ArrayList<>();
        if (root == null) return out;
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>(); queue.add(root);
        while (!queue.isEmpty() && out.size() < 600) {
            AccessibilityNodeInfo n = queue.remove(); out.add(n);
            for (int i = 0; i < n.getChildCount() && queue.size() < 600; i++) { AccessibilityNodeInfo c = n.getChild(i); if (c != null) queue.add(c); }
        }
        return out;
    }
    String snapshot() {
        StringBuilder b = new StringBuilder();
        for (AccessibilityNodeInfo n : nodes(appRoot())) {
            if (!n.isVisibleToUser() || n.isPassword()) continue;
            CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
            if (t != null && b.length() < 8000) b.append(t.toString(), 0, Math.min(t.length(), 200)).append('\n');
        }
        return b.toString();
    }
    String currentPackage() { AccessibilityNodeInfo r = appRoot(); return r == null ? "" : String.valueOf(r.getPackageName()); }
    static JSONArray apps(Context c) throws JSONException {
        JSONArray a = new JSONArray();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        HashSet<String> seen = new HashSet<>();
        for (ResolveInfo r : c.getPackageManager().queryIntentActivities(i, 0)) {
            if (seen.add(r.activityInfo.packageName)) a.put(new JSONObject().put("label", r.loadLabel(c.getPackageManager())).put("package", r.activityInfo.packageName));
        }
        return a;
    }
    String execute(JSONObject plan, String expectedPackage) throws Exception {
        if (locked()) return "Разблокируйте телефон.";
        String action = plan.getString("action"), value = plan.optString("value");
        switch (action) {
            case "none": return value;
            case "open_app":
                Intent launch = getPackageManager().getLaunchIntentForPackage(value);
                if (launch == null) return "Приложение не найдено.";
                startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return "Запрос открытия отправлен.";
            case "home": return result(performGlobalAction(GLOBAL_ACTION_HOME));
            case "back": return result(performGlobalAction(GLOBAL_ACTION_BACK));
            case "recents": return result(performGlobalAction(GLOBAL_ACTION_RECENTS));
        }
        if (expectedPackage.isEmpty() || !expectedPackage.equals(currentPackage())) return "Приложение на экране изменилось. Повторите команду.";
        List<AccessibilityNodeInfo> list = nodes(appRoot());
        if (action.equals("tap")) {
            ArrayList<AccessibilityNodeInfo> matches = new ArrayList<>();
            for (AccessibilityNodeInfo n : list) {
                if (!n.isVisibleToUser() || !n.isEnabled() || n.isPassword()) continue;
                if (value.equalsIgnoreCase(String.valueOf(n.getText())) || value.equalsIgnoreCase(String.valueOf(n.getContentDescription()))) matches.add(n);
            }
            if (matches.size() != 1) return "Нет однозначного элемента «" + value + "». Уточните команду.";
            AccessibilityNodeInfo n = matches.get(0);
            while (n != null && !n.isClickable()) n = n.getParent();
            return result(n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK));
        }
        if (action.equals("type")) {
            ArrayList<AccessibilityNodeInfo> fields = new ArrayList<>();
            for (AccessibilityNodeInfo n : list) if (n.isVisibleToUser() && n.isEnabled() && n.isEditable() && !n.isPassword()) fields.add(n);
            AccessibilityNodeInfo target = null;
            for (AccessibilityNodeInfo n : fields) if (n.isFocused()) target = n;
            if (target == null && fields.size() == 1) target = fields.get(0);
            if (target == null) return "Выберите поле ввода в приложении и повторите.";
            Bundle b = new Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
            return result(target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b));
        }
        if (action.equals("scroll_down") || action.equals("scroll_up")) {
            for (AccessibilityNodeInfo n : list) if (n.isVisibleToUser() && n.isScrollable() && n.performAction(action.equals("scroll_down") ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return "Прокручено.";
            return "Не удалось прокрутить этот экран.";
        }
        return "Действие не поддерживается.";
    }
    private static String result(boolean ok) { return ok ? "Android принял действие." : "Android не выполнил действие."; }
}
