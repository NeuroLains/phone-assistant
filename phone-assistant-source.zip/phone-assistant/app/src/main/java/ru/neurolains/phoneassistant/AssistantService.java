package ru.neurolains.phoneassistant;
public class AssistantService extends android.service.voice.VoiceInteractionService {}
