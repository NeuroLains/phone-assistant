package ru.neurolains.phoneassistant;
import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.speech.*;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class CommandPanel extends LinearLayout {
    static volatile String serverToken = "";
    final EditText input;
    final TextView status;
    final CheckBox share;
    final Button confirm;
    final Runnable dismiss;
    final Handler main = new Handler(Looper.getMainLooper());
    SpeechRecognizer speech;
    volatile int generation;
    JSONObject pending;
    String expectedPackage;
    volatile HttpURLConnection connection;
    public CommandPanel(Context c, Runnable dismiss) {
        super(c); this.dismiss=dismiss; setOrientation(VERTICAL); setPadding(24,24,24,24); setBackgroundColor(0xfff0f3f7);
        input=new EditText(c); input.setHint("Например: открой YouTube"); addView(input);
        share=new CheckBox(c); share.setText("Передать текст текущего экрана серверу и OpenAI для этой команды"); addView(share);
        status=new TextView(c); status.setText("Команды: назад, домой, приложения, вниз, вверх, открой…, нажми…, введи…"); addView(status);
        button("Говорить",this::listen); button("Подготовить действие",this::prepare);
        confirm=button("Выполнить показанное действие",this::execute); confirm.setVisibility(GONE);
        button("Отмена / закрыть",()->{cancel();dismiss.run();});
    }
    Button button(String title,Runnable run){Button b=new Button(getContext());b.setText(title);b.setOnClickListener(v->run.run());addView(b);return b;}
    void listen(){
        if(getContext().checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){status.setText("Разрешите микрофон в настройках приложения помощника.");return;}
        if(!SpeechRecognizer.isRecognitionAvailable(getContext())){status.setText("На телефоне нет службы распознавания речи. Можно ввести команду текстом.");return;}
        cancel(); speech=SpeechRecognizer.createSpeechRecognizer(getContext());
        speech.setRecognitionListener(new RecognitionListener(){
            public void onReadyForSpeech(Bundle b){status.setText("Слушаю…");}
            public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
            public void onError(int e){status.setText("Распознавание не завершено, код "+e);}
            public void onResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(r!=null&&!r.isEmpty()){input.setText(r.get(0));prepare();}}
            public void onPartialResults(Bundle b){} public void onEvent(int e,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU");speech.startListening(i);
    }
    void prepare(){
        cancel(); String command=input.getText().toString().trim(); if(command.isEmpty())return;
        PhoneAccess s=PhoneAccess.instance;
        if(s==null){status.setText("Включите службу помощника в специальных возможностях.");return;}
        if(s.locked()){status.setText("Разблокируйте телефон.");return;}
        expectedPackage=s.currentPackage(); int ticket=generation;
        try {
            JSONArray apps=PhoneAccess.apps(getContext());
            JSONObject local=localPlan(command,apps);
            if(local!=null){showPlan(local);return;}
            String url=getContext().getSharedPreferences("settings",0).getString("url","");
            if(url.isEmpty()||serverToken.isEmpty()){status.setText("Для свободных команд настройте HTTPS-сервер и токен. Сейчас доступны команды из подсказки.");return;}
            JSONObject payload=new JSONObject().put("command",command).put("apps",apps).put("screen",share.isChecked()?s.snapshot():"");
            share.setChecked(false); status.setText("Готовлю действие…");
            new Thread(()->{
                try{JSONObject plan=remote(url,payload);main.post(()->{if(ticket==generation)showPlan(plan);});}
                catch(Exception e){main.post(()->{if(ticket==generation)status.setText("Не удалось получить действие. Проверьте подключение и настройки сервера.");});}
            },"planner").start();
        }catch(Exception e){status.setText("Не удалось подготовить команду.");}
    }
    JSONObject localPlan(String raw,JSONArray apps)throws Exception{
        String q=raw.toLowerCase(Locale.ROOT).trim();String action=null,value="";
        switch(q){case "назад":action="back";break;case "домой":action="home";break;case "приложения":action="recents";break;case "вниз":action="scroll_down";break;case "вверх":action="scroll_up";break;}
        if(q.startsWith("нажми ")){action="tap";value=raw.substring(6).trim();}
        if(q.startsWith("введи ")){action="type";value=raw.substring(6);}
        if(q.startsWith("открой ")){
            String target=q.substring(7).trim(); if(target.equals("ютуб"))target="youtube";
            List<String> matches=new ArrayList<>();
            for(int i=0;i<apps.length();i++){JSONObject app=apps.getJSONObject(i);if(app.getString("label").equalsIgnoreCase(target)||app.getString("package").equalsIgnoreCase(target))matches.add(app.getString("package"));}
            if(matches.size()==1){action="open_app";value=matches.get(0);}
        }
        return action==null?null:new JSONObject().put("action",action).put("value",value);
    }
    void showPlan(JSONObject p){
        String a=p.optString("action"), v=p.optString("value");
        if(!Arrays.asList("none","open_app","back","home","recents","tap","type","scroll_down","scroll_up").contains(a)||v.length()>2000){status.setText("Сервер вернул неподдерживаемое действие.");return;}
        if(a.equals("none")){status.setText(v);return;}
        pending=p;
        String label;
        switch(a){case "open_app":label="Открыть приложение";break;case "tap":label="Нажать элемент";break;case "type":label="Заменить текст в выбранном поле";break;case "back":label="Назад";break;case "home":label="На главный экран";break;case "recents":label="Недавние приложения";break;case "scroll_down":label="Прокрутить вниз";break;default:label="Прокрутить вверх";}
        status.setText(label+(v.isEmpty()?"":"\n«"+v+"»")+"\nПроверьте действие и подтвердите.");confirm.setVisibility(VISIBLE);
    }
    void execute(){
        if(pending==null)return;JSONObject p=pending;String pkg=expectedPackage;
        cancel();dismiss.run();
        main.postDelayed(()->{try{PhoneAccess s=PhoneAccess.instance;String result=s==null?"Управление отключено.":s.execute(p,pkg);Toast.makeText(getContext(),result,Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(getContext(),"Не удалось выполнить действие.",Toast.LENGTH_LONG).show();}},400);
    }
    JSONObject remote(String endpoint,JSONObject body)throws Exception{
        URL url=new URL(endpoint);if(!"https".equals(url.getProtocol())||url.getUserInfo()!=null)throw new IOException("HTTPS required");
        HttpURLConnection c=(HttpURLConnection)url.openConnection();connection=c;
        try{
            c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(45000);c.setRequestMethod("POST");c.setDoOutput(true);
            c.setRequestProperty("Authorization","Bearer "+serverToken);c.setRequestProperty("Content-Type","application/json");
            try(OutputStream out=c.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}
            if(c.getResponseCode()!=200)throw new IOException("Server error");
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream in=c.getInputStream()){byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){if(bytes.size()+n>16384)throw new IOException("Response too large");bytes.write(buf,0,n);}}
            return new JSONObject(bytes.toString("UTF-8"));
        }finally{c.disconnect();if(connection==c)connection=null;}
    }
    public void cancel(){generation++;pending=null;confirm.setVisibility(GONE);if(speech!=null){speech.cancel();speech.destroy();speech=null;}HttpURLConnection c=connection;if(c!=null)c.disconnect();}
}
