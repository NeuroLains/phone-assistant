package ru.neurolains.phoneassistant;
import android.os.Bundle;
import android.view.View;
import android.service.voice.*;
public class AssistantSessionService extends VoiceInteractionSessionService {
    @Override public VoiceInteractionSession onNewSession(Bundle args) {
        return new VoiceInteractionSession(this) {
            CommandPanel panel;
            @Override public View onCreateContentView() {
                panel = new CommandPanel(getContext(), this::hide);
                return panel;
            }
            @Override public void onHide() { if (panel != null) panel.cancel(); super.onHide(); }
            @Override public void onDestroy() { if (panel != null) panel.cancel(); super.onDestroy(); }
        };
    }
}
