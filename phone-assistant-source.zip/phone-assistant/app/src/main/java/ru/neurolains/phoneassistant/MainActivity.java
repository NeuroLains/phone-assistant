package ru.neurolains.phoneassistant;
import android.Manifest;
import android.app.*;
import android.app.role.RoleManager;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.*;

public class MainActivity extends Activity {
    CommandPanel panel;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout l = new LinearLayout(this); l.setOrientation(1); l.setPadding(24,48,24,32);
        ScrollView scroll = new ScrollView(this); scroll.addView(l); setContentView(scroll);
        TextView title = new TextView(this); title.setText("Телефон\nЛичный помощник · прототип 0.1"); title.setTextSize(26); l.addView(title);
        TextView help = new TextView(this); help.setText("Для управления включите службу специальных возможностей и выберите помощника по умолчанию. Затем вызывайте его системным жестом поверх нужного приложения. Каждое действие требует вашего подтверждения."); l.addView(help);
        button(l,"1. Разрешить управление", () -> new AlertDialog.Builder(this).setTitle("Доступ к экрану")
            .setMessage(R.string.access_description).setNegativeButton("Отмена",null).setPositiveButton("Открыть настройки",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).show());
        button(l,"2. Сделать помощником", () -> {
            RoleManager r = getSystemService(RoleManager.class);
            if (r.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) startActivityForResult(r.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT), 2);
            else startActivity(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));
        });
        button(l,"3. Разрешить микрофон", () -> { if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},1); });
        TextView settings = new TextView(this); settings.setText("Для свободных команд: адрес вашего HTTPS-сервера и его токен. Простые команды работают без сервера."); l.addView(settings);
        SharedPreferences prefs = getSharedPreferences("settings",0);
        EditText url = new EditText(this); url.setHint("https://ваш-сервер/plan"); url.setSingleLine(); url.setText(prefs.getString("url","")); l.addView(url);
        EditText token = new EditText(this); token.setHint("Токен сервера (хранится до закрытия процесса)"); token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); l.addView(token);
        button(l,"Сохранить подключение", () -> { prefs.edit().putString("url",url.getText().toString().trim()).apply(); CommandPanel.serverToken=token.getText().toString(); token.setText(""); Toast.makeText(this,"Адрес сохранён. Токен только в памяти.",Toast.LENGTH_SHORT).show(); });
        button(l,"Отключить управление", () -> { if(PhoneAccess.instance!=null) PhoneAccess.instance.disableSelf(); CommandPanel.serverToken=""; });
        panel = new CommandPanel(this, () -> moveTaskToBack(true)); l.addView(panel);
    }
    void button(LinearLayout l,String title,Runnable run) { Button b = new Button(this); b.setText(title); b.setOnClickListener(v->run.run()); l.addView(b); }
    @Override protected void onDestroy() { if(panel!=null)panel.cancel(); super.onDestroy(); }
}
