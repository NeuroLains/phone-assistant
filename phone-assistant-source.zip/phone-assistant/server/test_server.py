import unittest
from server import validate_request, validate_plan

class BoundaryTests(unittest.TestCase):
    def test_valid_request(self):
        self.assertEqual(validate_request({'command':'назад'})['screen'], '')
    def test_reject_invalid_input(self):
        for data in [None, {}, {'command':[]}, {'command':'x','screen':{}}, {'command':'x','apps':[{'label':'a'}]}]:
            with self.subTest(data=data), self.assertRaises(ValueError): validate_request(data)
    def test_reject_unknown_action(self):
        with self.assertRaises(ValueError): validate_plan({'action':'shell','value':'id'},[])
    def test_reject_uninstalled_app(self):
        with self.assertRaises(ValueError): validate_plan({'action':'open_app','value':'unknown'},[])
    def test_valid_known_app(self):
        plan={'action':'open_app','value':'com.google.android.youtube'}
        self.assertEqual(validate_plan(plan,[{'package':plan['value']}]),plan)
    def test_no_hidden_extra_actions(self):
        with self.assertRaises(ValueError): validate_plan({'action':'back','value':'','next':'tap'},[])
    def test_reject_empty_target(self):
        with self.assertRaises(ValueError): validate_plan({'action':'tap','value':''},[])

if __name__ == '__main__': unittest.main()
